package model

data class Item(
    val Nama:String,
    val Harga:Int
)
