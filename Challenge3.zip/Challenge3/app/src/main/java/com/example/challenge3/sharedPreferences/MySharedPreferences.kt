package com.example.challenge3.sharedPreferences

class MySharedPreferences {
}