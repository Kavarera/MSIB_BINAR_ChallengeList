package com.example.challenge3.models

enum class EnumMetodePengiriman(value:Int) {
    AMBIL_SENDIRI(0),DIKIRIM(1)
}