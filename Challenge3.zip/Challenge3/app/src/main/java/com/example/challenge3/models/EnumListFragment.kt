package com.example.challenge3.models

import androidx.fragment.app.Fragment
import com.example.challenge3.page.MenuFragment

enum class EnumListFragment(val value:Int) {
    HOME(1),KERANJANG(2),RIWAYAT(3),PROFILE(4)

}