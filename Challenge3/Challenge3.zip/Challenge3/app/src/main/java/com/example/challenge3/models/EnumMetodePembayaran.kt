package com.example.challenge3.models

enum class EnumMetodePembayaran(value:Int) {
    TUNAI(0),DOMPET_DIGITAL(1)
}