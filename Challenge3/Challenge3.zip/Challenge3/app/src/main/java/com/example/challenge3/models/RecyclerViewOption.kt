package com.example.challenge3.models

enum class RecyclerViewOption(val value:Int) {
    LINEAR_LAYOUT(0),GRID_LAYOUT(1)
}